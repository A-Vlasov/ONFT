use crate::*;
use oapp::endpoint::{instructions::RegisterOAppParams, ID as ENDPOINT_ID};

#[account]
#[derive(InitSpace)]
pub struct ONftConfig {
    // immutable
    pub ld2sd_rate: u64,
    pub token_mint: Pubkey,
    pub token_program: Pubkey,
    pub endpoint_program: Pubkey,
    pub bump: u8,
    // mutable
    pub admin: Pubkey,
    pub ext: ONftConfigExt,
    pub fee_percentage: u64, 
}

#[derive(InitSpace, Clone, AnchorSerialize, AnchorDeserialize, PartialEq, Eq)]
pub enum ONftConfigExt {
    Native(Option<Pubkey>), // mint authority
    Adapter(Pubkey),        // token escrow
}

impl ONftConfig {
    pub fn init(
        &mut self,
        endpoint_program: Option<Pubkey>,
        admin: Pubkey,
        shared_decimals: u8,
        decimals: u8,
        accounts: &[AccountInfo],
        oapp_signer: Pubkey,
    ) -> Result<()> {
        self.admin = admin;
        self.endpoint_program = if let Some(endpoint_program) = endpoint_program {
            endpoint_program
        } else {
            ENDPOINT_ID
        };
        
        require!(
            ctx.accounts.token_mint.decimals - params.shared_decimals <= 9,
            ONFTError::InvalidDecimals
        );
        
        require!(
            ctx.accounts.token_mint.decimals <= 12,
            ONFTError::InvalidDecimals
        );
        
        self.ld2sd_rate = 10u64.pow((decimals - shared_decimals) as u32);

        // register oapp
        oapp::endpoint_cpi::register_oapp(
            self.endpoint_program,
            oapp_signer,
            accounts,
            &[ONft_SEED, &get_ONft_config_seed(self).to_bytes(), &[self.bump]],
            RegisterOAppParams { delegate: self.admin },
        )?;

        emit!(ONftConfigInitialized {
            admin: self.admin,
            endpoint_program: self.endpoint_program,
            shared_decimals,
            decimals,
            ld2sd_rate: self.ld2sd_rate,
        });

        Ok(())
    }

    pub fn ld2sd(&self, amount_ld: u64) -> u64 {
        amount_ld / self.ld2sd_rate
    }

    pub fn sd2ld(&self, amount_sd: u64) -> u64 {
        amount_sd * self.ld2sd_rate
    }

    pub fn remove_dust(&self, amount_ld: u64) -> u64 {
        amount_ld - amount_ld % self.ld2sd_rate
    }
}

/// LzReceiveTypesAccounts includes accounts that are used in the LzReceiveTypes
/// instruction.
#[account]
#[derive(InitSpace)]
pub struct LzReceiveTypesAccounts {
    pub ONft_config: Pubkey,
    pub token_mint: Pubkey,
}